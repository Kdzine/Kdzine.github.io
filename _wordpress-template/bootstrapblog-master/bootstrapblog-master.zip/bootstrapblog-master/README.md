Bootstrap Blog
=======

Build on the official Bootstrap blog starter template to learn WordPress.

[View the tutorial](http://www.taniarascia.com/developing-a-wordpress-theme-from-scratch/) on how to develop a WordPress theme from scratch.
